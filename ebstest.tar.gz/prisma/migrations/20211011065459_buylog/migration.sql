/*
  Warnings:

  - You are about to drop the column `itemId` on the `BuyLog` table. All the data in the column will be lost.
  - You are about to drop the column `shopId` on the `BuyLog` table. All the data in the column will be lost.
  - Added the required column `customerId` to the `BuyLog` table without a default value. This is not possible if the table is not empty.
  - Added the required column `productId` to the `BuyLog` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "BuyLog" DROP COLUMN "itemId",
DROP COLUMN "shopId",
ADD COLUMN     "customerId" INTEGER NOT NULL,
ADD COLUMN     "productId" INTEGER NOT NULL;

-- CreateTable
CREATE TABLE "Product" (
    "id" SERIAL NOT NULL,

    CONSTRAINT "Product_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "BuyLog" ADD CONSTRAINT "BuyLog_productId_fkey" FOREIGN KEY ("productId") REFERENCES "Product"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "BuyLog" ADD CONSTRAINT "BuyLog_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
