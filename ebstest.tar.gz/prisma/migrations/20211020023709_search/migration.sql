/*
  Warnings:

  - You are about to drop the column `stringBC` on the `Photolog` table. All the data in the column will be lost.
  - You are about to drop the column `stringC` on the `Photolog` table. All the data in the column will be lost.
  - You are about to drop the column `stringST` on the `Photolog` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "Photolog" DROP COLUMN "stringBC",
DROP COLUMN "stringC",
DROP COLUMN "stringST";
