/*
  Warnings:

  - You are about to drop the column `readedAt` on the `ChatroomReaded` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "ChatroomReaded" DROP COLUMN "readedAt";
