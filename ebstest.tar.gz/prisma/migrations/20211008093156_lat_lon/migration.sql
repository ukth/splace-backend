/*
  Warnings:

  - You are about to drop the column `location` on the `Splace` table. All the data in the column will be lost.
  - Added the required column `lat` to the `Splace` table without a default value. This is not possible if the table is not empty.
  - Added the required column `lon` to the `Splace` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "Splace" DROP COLUMN "location",
ADD COLUMN     "lat" DECIMAL(11,8) NOT NULL,
ADD COLUMN     "lon" DECIMAL(11,8) NOT NULL;
