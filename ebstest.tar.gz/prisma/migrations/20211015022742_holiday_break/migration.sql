-- AlterTable
ALTER TABLE "Splace" ADD COLUMN     "holidayBreak" BOOLEAN NOT NULL DEFAULT false;
