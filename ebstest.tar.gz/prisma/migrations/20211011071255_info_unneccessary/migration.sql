/*
  Warnings:

  - You are about to drop the `BuyLog` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `Product` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropForeignKey
ALTER TABLE "BuyLog" DROP CONSTRAINT "BuyLog_customerId_fkey";

-- DropForeignKey
ALTER TABLE "BuyLog" DROP CONSTRAINT "BuyLog_productId_fkey";

-- DropTable
DROP TABLE "BuyLog";

-- DropTable
DROP TABLE "Product";

-- CreateTable
CREATE TABLE "BuyRaffleLog" (
    "id" SERIAL NOT NULL,
    "raffleId" INTEGER NOT NULL,
    "customerId" INTEGER NOT NULL,
    "credit" INTEGER NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "BuyRaffleLog_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Raffle" (
    "id" SERIAL NOT NULL,
    "name" VARCHAR(255) NOT NULL,
    "dDay" TIMESTAMP(3) NOT NULL,
    "imageUrls" VARCHAR(255)[],
    "credit" INTEGER NOT NULL,
    "splaceId" INTEGER,
    "info" TEXT,

    CONSTRAINT "Raffle_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "BuyRaffleLog" ADD CONSTRAINT "BuyRaffleLog_raffleId_fkey" FOREIGN KEY ("raffleId") REFERENCES "Raffle"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "BuyRaffleLog" ADD CONSTRAINT "BuyRaffleLog_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Raffle" ADD CONSTRAINT "Raffle_splaceId_fkey" FOREIGN KEY ("splaceId") REFERENCES "Splace"("id") ON DELETE SET NULL ON UPDATE CASCADE;
