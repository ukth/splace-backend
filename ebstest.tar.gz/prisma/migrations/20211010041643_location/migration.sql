/*
  Warnings:

  - Added the required column `location` to the `Splace` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "Splace" ADD COLUMN     "location" VARCHAR(255) NOT NULL,
ALTER COLUMN "lat" DROP NOT NULL,
ALTER COLUMN "lon" DROP NOT NULL;
