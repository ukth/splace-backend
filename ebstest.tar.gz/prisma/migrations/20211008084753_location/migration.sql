/*
  Warnings:

  - The `location` column on the `Splace` table would be dropped and recreated. This will lead to data loss if there is data in the column.

*/
-- AlterTable
ALTER TABLE "Splace" DROP COLUMN "location",
ADD COLUMN     "location" DECIMAL(11,8)[];
