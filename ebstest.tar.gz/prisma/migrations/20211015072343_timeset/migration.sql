/*
  Warnings:

  - You are about to drop the column `isBreakTime` on the `TimeSet` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "TimeSet" DROP COLUMN "isBreakTime",
ADD COLUMN     "breakClose" TIME,
ADD COLUMN     "breakOpen" TIME,
ALTER COLUMN "open" DROP NOT NULL,
ALTER COLUMN "close" DROP NOT NULL;
