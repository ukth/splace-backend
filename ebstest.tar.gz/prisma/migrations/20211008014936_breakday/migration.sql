-- CreateTable
CREATE TABLE "BreakDay" (
    "id" SERIAL NOT NULL,
    "week" INTEGER NOT NULL,
    "day" INTEGER NOT NULL,
    "splaceId" INTEGER,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "BreakDay_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "BreakDay" ADD CONSTRAINT "BreakDay_splaceId_fkey" FOREIGN KEY ("splaceId") REFERENCES "Splace"("id") ON DELETE SET NULL ON UPDATE CASCADE;
