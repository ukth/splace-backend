/*
  Warnings:

  - Added the required column `color` to the `Ratingtag` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "Photolog" ADD COLUMN     "stringBC" VARCHAR(255),
ADD COLUMN     "stringC" VARCHAR(255),
ADD COLUMN     "stringST" VARCHAR(255);

-- AlterTable
ALTER TABLE "Ratingtag" ADD COLUMN     "color" VARCHAR(255) NOT NULL;

-- AlterTable
ALTER TABLE "Splace" ADD COLUMN     "stringBC" VARCHAR(255),
ADD COLUMN     "stringC" VARCHAR(255),
ADD COLUMN     "stringRT" VARCHAR(255),
ADD COLUMN     "stringST" VARCHAR(255);
