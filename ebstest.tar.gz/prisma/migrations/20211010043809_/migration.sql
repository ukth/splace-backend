-- AlterTable
ALTER TABLE "Splace" ALTER COLUMN "location" DROP NOT NULL;
