/*
  Warnings:

  - You are about to drop the column `stringBC` on the `Splace` table. All the data in the column will be lost.
  - You are about to drop the column `stringC` on the `Splace` table. All the data in the column will be lost.
  - You are about to drop the column `stringRT` on the `Splace` table. All the data in the column will be lost.
  - You are about to drop the column `stringST` on the `Splace` table. All the data in the column will be lost.
  - You are about to drop the `BreakDay` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropForeignKey
ALTER TABLE "BreakDay" DROP CONSTRAINT "BreakDay_splaceId_fkey";

-- AlterTable
ALTER TABLE "Splace" DROP COLUMN "stringBC",
DROP COLUMN "stringC",
DROP COLUMN "stringRT",
DROP COLUMN "stringST",
ADD COLUMN     "breakDays" INTEGER[];

-- DropTable
DROP TABLE "BreakDay";
