/*
  Warnings:

  - You are about to alter the column `location` on the `Splace` table. The data in that column could be lost. The data in that column will be cast from `Decimal(11,8)` to `VarChar(255)`.

*/
-- AlterTable
ALTER TABLE "Splace" ALTER COLUMN "location" SET NOT NULL,
ALTER COLUMN "location" SET DATA TYPE VARCHAR(255);
