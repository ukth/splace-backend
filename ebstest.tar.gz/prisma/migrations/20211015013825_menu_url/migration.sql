/*
  Warnings:

  - You are about to drop the `Item` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropForeignKey
ALTER TABLE "Item" DROP CONSTRAINT "Item_splaceId_fkey";

-- AlterTable
ALTER TABLE "Splace" ADD COLUMN     "itemName" VARCHAR,
ADD COLUMN     "itemPrice" INTEGER,
ADD COLUMN     "menuUrls" VARCHAR(255)[];

-- DropTable
DROP TABLE "Item";
