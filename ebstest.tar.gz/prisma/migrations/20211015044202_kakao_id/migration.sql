-- AlterTable
ALTER TABLE "Splace" ADD COLUMN     "kakaoId" INTEGER;
