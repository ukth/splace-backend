/*
  Warnings:

  - You are about to drop the column `kids` on the `Splace` table. All the data in the column will be lost.
  - Made the column `parking` on table `Splace` required. This step will fail if there are existing NULL values in that column.
  - Made the column `pets` on table `Splace` required. This step will fail if there are existing NULL values in that column.

*/
-- AlterTable
ALTER TABLE "Splace" DROP COLUMN "kids",
ADD COLUMN     "noKids" BOOLEAN NOT NULL DEFAULT false,
ALTER COLUMN "parking" SET NOT NULL,
ALTER COLUMN "parking" SET DEFAULT false,
ALTER COLUMN "pets" SET NOT NULL,
ALTER COLUMN "pets" SET DEFAULT false;

-- AlterTable
ALTER TABLE "User" ADD COLUMN     "birthDay" TIMESTAMP(3);

-- RenameIndex
ALTER INDEX "Chatroom_lastMessageId_unique" RENAME TO "Chatroom_lastMessageId_key";

-- RenameIndex
ALTER INDEX "Item_splaceId_unique" RENAME TO "Item_splaceId_key";
