-- AlterTable
ALTER TABLE "Splace" ADD COLUMN     "activate" BOOLEAN NOT NULL DEFAULT false;
