/*
  Warnings:

  - You are about to drop the `Scrap` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropForeignKey
ALTER TABLE "Scrap" DROP CONSTRAINT "Scrap_photologId_fkey";

-- DropForeignKey
ALTER TABLE "Scrap" DROP CONSTRAINT "Scrap_savedUserId_fkey";

-- DropTable
DROP TABLE "Scrap";

-- CreateTable
CREATE TABLE "ScrapedLog" (
    "id" SERIAL NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "photologId" INTEGER,
    "savedUserId" INTEGER,

    CONSTRAINT "ScrapedLog_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ScrapedSeries" (
    "id" SERIAL NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "seriesId" INTEGER,
    "savedUserId" INTEGER,

    CONSTRAINT "ScrapedSeries_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "ScrapedLog" ADD CONSTRAINT "ScrapedLog_photologId_fkey" FOREIGN KEY ("photologId") REFERENCES "Photolog"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ScrapedLog" ADD CONSTRAINT "ScrapedLog_savedUserId_fkey" FOREIGN KEY ("savedUserId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ScrapedSeries" ADD CONSTRAINT "ScrapedSeries_seriesId_fkey" FOREIGN KEY ("seriesId") REFERENCES "Series"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ScrapedSeries" ADD CONSTRAINT "ScrapedSeries_savedUserId_fkey" FOREIGN KEY ("savedUserId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
