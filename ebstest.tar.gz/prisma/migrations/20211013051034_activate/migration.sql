-- AlterTable
ALTER TABLE "User" ADD COLUMN     "activate" BOOLEAN NOT NULL DEFAULT true;
