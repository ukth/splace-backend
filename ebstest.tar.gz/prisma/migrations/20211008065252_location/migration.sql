/*
  Warnings:

  - You are about to drop the column `geolat` on the `Splace` table. All the data in the column will be lost.
  - You are about to drop the column `geolog` on the `Splace` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "Splace" DROP COLUMN "geolat",
DROP COLUMN "geolog",
ADD COLUMN     "location" DECIMAL(11,8)[];
