-- CreateTable
CREATE TABLE "User" (
    "id" SERIAL NOT NULL,
    "username" TEXT NOT NULL,
    "name" VARCHAR(255),
    "email" VARCHAR(255) NOT NULL,
    "password" VARCHAR(255) NOT NULL,
    "profileMessage" VARCHAR(255),
    "profileImageUrl" VARCHAR(255),
    "joinedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "authority" VARCHAR(255) NOT NULL DEFAULT E'user',
    "credit" INTEGER NOT NULL DEFAULT 0,
    "lockedCredit" INTEGER NOT NULL DEFAULT 0,
    "url" VARCHAR(255),
    "phone" VARCHAR(255),

    CONSTRAINT "User_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Photolog" (
    "id" SERIAL NOT NULL,
    "title" VARCHAR(255) NOT NULL,
    "imageUrls" VARCHAR(255)[],
    "photoSize" INTEGER NOT NULL,
    "text" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "isPrivate" BOOLEAN NOT NULL DEFAULT false,
    "authorId" INTEGER NOT NULL,
    "splaceId" INTEGER,

    CONSTRAINT "Photolog_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Series" (
    "id" SERIAL NOT NULL,
    "title" VARCHAR(255) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "isPrivate" BOOLEAN NOT NULL DEFAULT false,
    "authorId" INTEGER NOT NULL,

    CONSTRAINT "Series_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Splace" (
    "id" SERIAL NOT NULL,
    "name" VARCHAR(255) NOT NULL,
    "geolog" DECIMAL(11,8),
    "geolat" DECIMAL(11,8),
    "address" VARCHAR(255),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "ownerId" INTEGER,
    "parking" BOOLEAN,
    "pets" BOOLEAN,
    "kids" BOOLEAN,
    "intro" TEXT,
    "url" VARCHAR(255),
    "phone" VARCHAR(255),
    "thumbnail" TEXT,

    CONSTRAINT "Splace_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "TimeSet" (
    "id" SERIAL NOT NULL,
    "open" TIME NOT NULL,
    "close" TIME NOT NULL,
    "day" INTEGER NOT NULL,
    "splaceId" INTEGER,
    "isBreakTime" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "TimeSet_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "FixedContent" (
    "id" SERIAL NOT NULL,
    "title" VARCHAR(255) NOT NULL,
    "imageUrl" VARCHAR(255),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "text" TEXT,
    "splaceId" INTEGER,

    CONSTRAINT "FixedContent_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Ratingtag" (
    "id" SERIAL NOT NULL,
    "name" VARCHAR(255) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Ratingtag_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Save" (
    "id" SERIAL NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "splaceId" INTEGER,
    "folderId" INTEGER,

    CONSTRAINT "Save_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Scrap" (
    "id" SERIAL NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "photologId" INTEGER,
    "savedUserId" INTEGER,

    CONSTRAINT "Scrap_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Folder" (
    "id" SERIAL NOT NULL,
    "title" VARCHAR(255) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Folder_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Category" (
    "id" SERIAL NOT NULL,
    "name" VARCHAR(255) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Category_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "BigCategory" (
    "id" SERIAL NOT NULL,
    "name" VARCHAR(255) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "BigCategory_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Specialtag" (
    "id" SERIAL NOT NULL,
    "name" VARCHAR(255) NOT NULL,
    "color" VARCHAR(255) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Specialtag_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Item" (
    "id" SERIAL NOT NULL,
    "name" TEXT NOT NULL,
    "price" INTEGER,
    "imageUrls" VARCHAR(255)[],
    "splaceId" INTEGER NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Item_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Comment" (
    "id" SERIAL NOT NULL,
    "text" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "authorId" INTEGER,
    "photologId" INTEGER,

    CONSTRAINT "Comment_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "PaymentLog" (
    "id" SERIAL NOT NULL,
    "customerId" INTEGER NOT NULL,
    "merchantUId" VARCHAR(255) NOT NULL,
    "credit" INTEGER NOT NULL,
    "creditGiven" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "PaymentLog_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "BuyLog" (
    "id" SERIAL NOT NULL,
    "itemId" INTEGER NOT NULL,
    "shopId" INTEGER NOT NULL,
    "credit" INTEGER NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "BuyLog_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Chatroom" (
    "id" SERIAL NOT NULL,
    "title" VARCHAR(255) NOT NULL,
    "lastMessageId" INTEGER,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Chatroom_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ChatroomReaded" (
    "id" SERIAL NOT NULL,
    "userId" INTEGER,
    "chatroomId" INTEGER,
    "readedAt" TIMESTAMP(3) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ChatroomReaded_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Message" (
    "id" SERIAL NOT NULL,
    "text" TEXT NOT NULL,
    "authorId" INTEGER NOT NULL,
    "chatroomId" INTEGER NOT NULL,
    "unreadCount" INTEGER NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Message_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Moment" (
    "id" SERIAL NOT NULL,
    "text" TEXT,
    "authorId" INTEGER NOT NULL,
    "splaceId" INTEGER,
    "videoUrl" VARCHAR(255),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Moment_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "_followRelation" (
    "A" INTEGER NOT NULL,
    "B" INTEGER NOT NULL
);

-- CreateTable
CREATE TABLE "_folderRelation" (
    "A" INTEGER NOT NULL,
    "B" INTEGER NOT NULL
);

-- CreateTable
CREATE TABLE "_likedRelation" (
    "A" INTEGER NOT NULL,
    "B" INTEGER NOT NULL
);

-- CreateTable
CREATE TABLE "_likedCommentRelation" (
    "A" INTEGER NOT NULL,
    "B" INTEGER NOT NULL
);

-- CreateTable
CREATE TABLE "_ChatroomToUser" (
    "A" INTEGER NOT NULL,
    "B" INTEGER NOT NULL
);

-- CreateTable
CREATE TABLE "_hiddenLogsRelation" (
    "A" INTEGER NOT NULL,
    "B" INTEGER NOT NULL
);

-- CreateTable
CREATE TABLE "_hiddenSeriesRelation" (
    "A" INTEGER NOT NULL,
    "B" INTEGER NOT NULL
);

-- CreateTable
CREATE TABLE "_blockRelation" (
    "A" INTEGER NOT NULL,
    "B" INTEGER NOT NULL
);

-- CreateTable
CREATE TABLE "_seriesRelation" (
    "A" INTEGER NOT NULL,
    "B" INTEGER NOT NULL
);

-- CreateTable
CREATE TABLE "_CategoryToPhotolog" (
    "A" INTEGER NOT NULL,
    "B" INTEGER NOT NULL
);

-- CreateTable
CREATE TABLE "_BigCategoryToPhotolog" (
    "A" INTEGER NOT NULL,
    "B" INTEGER NOT NULL
);

-- CreateTable
CREATE TABLE "_PhotologToSpecialtag" (
    "A" INTEGER NOT NULL,
    "B" INTEGER NOT NULL
);

-- CreateTable
CREATE TABLE "_RatingtagToSplace" (
    "A" INTEGER NOT NULL,
    "B" INTEGER NOT NULL
);

-- CreateTable
CREATE TABLE "_CategoryToSplace" (
    "A" INTEGER NOT NULL,
    "B" INTEGER NOT NULL
);

-- CreateTable
CREATE TABLE "_BigCategoryToSplace" (
    "A" INTEGER NOT NULL,
    "B" INTEGER NOT NULL
);

-- CreateTable
CREATE TABLE "_SpecialtagToSplace" (
    "A" INTEGER NOT NULL,
    "B" INTEGER NOT NULL
);

-- CreateIndex
CREATE UNIQUE INDEX "User_username_key" ON "User"("username");

-- CreateIndex
CREATE UNIQUE INDEX "Ratingtag_name_key" ON "Ratingtag"("name");

-- CreateIndex
CREATE UNIQUE INDEX "Category_name_key" ON "Category"("name");

-- CreateIndex
CREATE UNIQUE INDEX "BigCategory_name_key" ON "BigCategory"("name");

-- CreateIndex
CREATE UNIQUE INDEX "Specialtag_name_key" ON "Specialtag"("name");

-- CreateIndex
CREATE UNIQUE INDEX "Item_splaceId_unique" ON "Item"("splaceId");

-- CreateIndex
CREATE UNIQUE INDEX "PaymentLog_merchantUId_key" ON "PaymentLog"("merchantUId");

-- CreateIndex
CREATE UNIQUE INDEX "Chatroom_lastMessageId_unique" ON "Chatroom"("lastMessageId");

-- CreateIndex
CREATE UNIQUE INDEX "_followRelation_AB_unique" ON "_followRelation"("A", "B");

-- CreateIndex
CREATE INDEX "_followRelation_B_index" ON "_followRelation"("B");

-- CreateIndex
CREATE UNIQUE INDEX "_folderRelation_AB_unique" ON "_folderRelation"("A", "B");

-- CreateIndex
CREATE INDEX "_folderRelation_B_index" ON "_folderRelation"("B");

-- CreateIndex
CREATE UNIQUE INDEX "_likedRelation_AB_unique" ON "_likedRelation"("A", "B");

-- CreateIndex
CREATE INDEX "_likedRelation_B_index" ON "_likedRelation"("B");

-- CreateIndex
CREATE UNIQUE INDEX "_likedCommentRelation_AB_unique" ON "_likedCommentRelation"("A", "B");

-- CreateIndex
CREATE INDEX "_likedCommentRelation_B_index" ON "_likedCommentRelation"("B");

-- CreateIndex
CREATE UNIQUE INDEX "_ChatroomToUser_AB_unique" ON "_ChatroomToUser"("A", "B");

-- CreateIndex
CREATE INDEX "_ChatroomToUser_B_index" ON "_ChatroomToUser"("B");

-- CreateIndex
CREATE UNIQUE INDEX "_hiddenLogsRelation_AB_unique" ON "_hiddenLogsRelation"("A", "B");

-- CreateIndex
CREATE INDEX "_hiddenLogsRelation_B_index" ON "_hiddenLogsRelation"("B");

-- CreateIndex
CREATE UNIQUE INDEX "_hiddenSeriesRelation_AB_unique" ON "_hiddenSeriesRelation"("A", "B");

-- CreateIndex
CREATE INDEX "_hiddenSeriesRelation_B_index" ON "_hiddenSeriesRelation"("B");

-- CreateIndex
CREATE UNIQUE INDEX "_blockRelation_AB_unique" ON "_blockRelation"("A", "B");

-- CreateIndex
CREATE INDEX "_blockRelation_B_index" ON "_blockRelation"("B");

-- CreateIndex
CREATE UNIQUE INDEX "_seriesRelation_AB_unique" ON "_seriesRelation"("A", "B");

-- CreateIndex
CREATE INDEX "_seriesRelation_B_index" ON "_seriesRelation"("B");

-- CreateIndex
CREATE UNIQUE INDEX "_CategoryToPhotolog_AB_unique" ON "_CategoryToPhotolog"("A", "B");

-- CreateIndex
CREATE INDEX "_CategoryToPhotolog_B_index" ON "_CategoryToPhotolog"("B");

-- CreateIndex
CREATE UNIQUE INDEX "_BigCategoryToPhotolog_AB_unique" ON "_BigCategoryToPhotolog"("A", "B");

-- CreateIndex
CREATE INDEX "_BigCategoryToPhotolog_B_index" ON "_BigCategoryToPhotolog"("B");

-- CreateIndex
CREATE UNIQUE INDEX "_PhotologToSpecialtag_AB_unique" ON "_PhotologToSpecialtag"("A", "B");

-- CreateIndex
CREATE INDEX "_PhotologToSpecialtag_B_index" ON "_PhotologToSpecialtag"("B");

-- CreateIndex
CREATE UNIQUE INDEX "_RatingtagToSplace_AB_unique" ON "_RatingtagToSplace"("A", "B");

-- CreateIndex
CREATE INDEX "_RatingtagToSplace_B_index" ON "_RatingtagToSplace"("B");

-- CreateIndex
CREATE UNIQUE INDEX "_CategoryToSplace_AB_unique" ON "_CategoryToSplace"("A", "B");

-- CreateIndex
CREATE INDEX "_CategoryToSplace_B_index" ON "_CategoryToSplace"("B");

-- CreateIndex
CREATE UNIQUE INDEX "_BigCategoryToSplace_AB_unique" ON "_BigCategoryToSplace"("A", "B");

-- CreateIndex
CREATE INDEX "_BigCategoryToSplace_B_index" ON "_BigCategoryToSplace"("B");

-- CreateIndex
CREATE UNIQUE INDEX "_SpecialtagToSplace_AB_unique" ON "_SpecialtagToSplace"("A", "B");

-- CreateIndex
CREATE INDEX "_SpecialtagToSplace_B_index" ON "_SpecialtagToSplace"("B");

-- AddForeignKey
ALTER TABLE "Photolog" ADD CONSTRAINT "Photolog_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Photolog" ADD CONSTRAINT "Photolog_splaceId_fkey" FOREIGN KEY ("splaceId") REFERENCES "Splace"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Series" ADD CONSTRAINT "Series_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TimeSet" ADD CONSTRAINT "TimeSet_splaceId_fkey" FOREIGN KEY ("splaceId") REFERENCES "Splace"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "FixedContent" ADD CONSTRAINT "FixedContent_splaceId_fkey" FOREIGN KEY ("splaceId") REFERENCES "Splace"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Save" ADD CONSTRAINT "Save_splaceId_fkey" FOREIGN KEY ("splaceId") REFERENCES "Splace"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Save" ADD CONSTRAINT "Save_folderId_fkey" FOREIGN KEY ("folderId") REFERENCES "Folder"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Scrap" ADD CONSTRAINT "Scrap_photologId_fkey" FOREIGN KEY ("photologId") REFERENCES "Photolog"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Scrap" ADD CONSTRAINT "Scrap_savedUserId_fkey" FOREIGN KEY ("savedUserId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Item" ADD CONSTRAINT "Item_splaceId_fkey" FOREIGN KEY ("splaceId") REFERENCES "Splace"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Comment" ADD CONSTRAINT "Comment_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Comment" ADD CONSTRAINT "Comment_photologId_fkey" FOREIGN KEY ("photologId") REFERENCES "Photolog"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Chatroom" ADD CONSTRAINT "Chatroom_lastMessageId_fkey" FOREIGN KEY ("lastMessageId") REFERENCES "Message"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ChatroomReaded" ADD CONSTRAINT "ChatroomReaded_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ChatroomReaded" ADD CONSTRAINT "ChatroomReaded_chatroomId_fkey" FOREIGN KEY ("chatroomId") REFERENCES "Chatroom"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Message" ADD CONSTRAINT "Message_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Message" ADD CONSTRAINT "Message_chatroomId_fkey" FOREIGN KEY ("chatroomId") REFERENCES "Chatroom"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Moment" ADD CONSTRAINT "Moment_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Moment" ADD CONSTRAINT "Moment_splaceId_fkey" FOREIGN KEY ("splaceId") REFERENCES "Splace"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_followRelation" ADD FOREIGN KEY ("A") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_followRelation" ADD FOREIGN KEY ("B") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_folderRelation" ADD FOREIGN KEY ("A") REFERENCES "Folder"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_folderRelation" ADD FOREIGN KEY ("B") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_likedRelation" ADD FOREIGN KEY ("A") REFERENCES "Photolog"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_likedRelation" ADD FOREIGN KEY ("B") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_likedCommentRelation" ADD FOREIGN KEY ("A") REFERENCES "Comment"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_likedCommentRelation" ADD FOREIGN KEY ("B") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_ChatroomToUser" ADD FOREIGN KEY ("A") REFERENCES "Chatroom"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_ChatroomToUser" ADD FOREIGN KEY ("B") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_hiddenLogsRelation" ADD FOREIGN KEY ("A") REFERENCES "Photolog"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_hiddenLogsRelation" ADD FOREIGN KEY ("B") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_hiddenSeriesRelation" ADD FOREIGN KEY ("A") REFERENCES "Series"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_hiddenSeriesRelation" ADD FOREIGN KEY ("B") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_blockRelation" ADD FOREIGN KEY ("A") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_blockRelation" ADD FOREIGN KEY ("B") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_seriesRelation" ADD FOREIGN KEY ("A") REFERENCES "Photolog"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_seriesRelation" ADD FOREIGN KEY ("B") REFERENCES "Series"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_CategoryToPhotolog" ADD FOREIGN KEY ("A") REFERENCES "Category"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_CategoryToPhotolog" ADD FOREIGN KEY ("B") REFERENCES "Photolog"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_BigCategoryToPhotolog" ADD FOREIGN KEY ("A") REFERENCES "BigCategory"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_BigCategoryToPhotolog" ADD FOREIGN KEY ("B") REFERENCES "Photolog"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_PhotologToSpecialtag" ADD FOREIGN KEY ("A") REFERENCES "Photolog"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_PhotologToSpecialtag" ADD FOREIGN KEY ("B") REFERENCES "Specialtag"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_RatingtagToSplace" ADD FOREIGN KEY ("A") REFERENCES "Ratingtag"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_RatingtagToSplace" ADD FOREIGN KEY ("B") REFERENCES "Splace"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_CategoryToSplace" ADD FOREIGN KEY ("A") REFERENCES "Category"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_CategoryToSplace" ADD FOREIGN KEY ("B") REFERENCES "Splace"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_BigCategoryToSplace" ADD FOREIGN KEY ("A") REFERENCES "BigCategory"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_BigCategoryToSplace" ADD FOREIGN KEY ("B") REFERENCES "Splace"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_SpecialtagToSplace" ADD FOREIGN KEY ("A") REFERENCES "Specialtag"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_SpecialtagToSplace" ADD FOREIGN KEY ("B") REFERENCES "Splace"("id") ON DELETE CASCADE ON UPDATE CASCADE;
