/*
  Warnings:

  - You are about to drop the column `location` on the `Splace` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "Splace" DROP COLUMN "location";
